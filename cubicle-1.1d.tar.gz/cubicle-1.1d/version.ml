let version = "1.1d-1663M"
let date = "Wed Feb 10 16:11:17 CST 2016"
let libdir = "/usr/local/lib/cubicle"
