let version = "1.1b-1599"
let date = "Sun Nov 22 21:36:55 CST 2015"
let libdir = "/usr/local/lib/cubicle"
