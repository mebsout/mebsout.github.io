let version = "1.1c-1610"
let date = "Thu Dec 17 17:15:48 CST 2015"
let libdir = "/usr/local/lib/cubicle"
