let version = "1.1a-1582"
let date = "Tue Oct 27 02:32:45 CDT 2015"
let libdir = "/usr/local/lib/cubicle"
