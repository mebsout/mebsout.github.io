let version = "1.1.1a-1688"
let date = "Thu Mar 17 17:16:08 CDT 2016"
let libdir = "/usr/local/lib/cubicle"
