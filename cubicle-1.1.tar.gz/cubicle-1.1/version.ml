let version = "1.1"
let date = "Wed Mar 2 10:32:49 CST 2016"
let libdir = "/usr/local/lib/cubicle"
