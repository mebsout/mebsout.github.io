let version = "1.1.1b-1732"
let date = "Thu May 5 12:03:08 CDT 2016"
let libdir = "/usr/local/lib/cubicle"
